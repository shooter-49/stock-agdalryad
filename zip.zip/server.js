const express = require('express');
const fs = require('fs');
const path = require('path');
const app = express();

const multer = require('multer');
const XLSX = require('xlsx');
const mammoth = require('mammoth');
const upload = multer({ dest: 'uploads/' });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Redirection racine → page de login
app.get('/', (req, res) => {
  res.redirect('/login.html');
});

const DB_PATH = path.join(__dirname, 'db.json');

function readDB() {
  const data = JSON.parse(fs.readFileSync(DB_PATH, 'utf-8'));
  // Gardes défensives : s'assurer que les tableaux/objets existent
  if (!data.historique) data.historique = [];
  if (!data.mouvements) data.mouvements = [];
  if (!data.reservations) data.reservations = [];
  if (!data._counters) data._counters = { article_custom_id: 0, mouvement_id: 0, historique_id: 0, reservation_id: 0 };
  return data;
}

function writeDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
}

function addHistorique(db, user, action, articleId, detail, ancienne, nouvelle) {
  db._counters.historique_id++;
  db.historique.unshift({
    id: db._counters.historique_id,
    date: new Date().toISOString(),
    utilisateur: user,
    action,
    article_id: articleId,
    detail,
    ancienne_valeur: ancienne || '',
    nouvelle_valeur: nouvelle || ''
  });
}

// AUTH
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;
  const db = readDB();
  const user = db.users.find(u => u.username === username && u.password === password);
  if (!user) return res.status(401).json({ error: 'Identifiants incorrects / بيانات خاطئة' });
  res.json({ success: true, user: { id: user.id, username: user.username, role: user.role, nom: user.nom } });
});

// CATEGORIES
app.get('/api/categories', (req, res) => {
  res.json(readDB().categories);
});

app.post('/api/categories', (req, res) => {
  const db = readDB();
  const maxId = Math.max(...db.categories.map(c => c.id), 0);
  const cat = { id: maxId + 1, ...req.body };
  db.categories.push(cat);
  writeDB(db);
  res.json(cat);
});

app.put('/api/categories/:id', (req, res) => {
  const db = readDB();
  const idx = db.categories.findIndex(c => c.id == req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Catégorie non trouvée' });
  db.categories[idx] = { ...db.categories[idx], ...req.body };
  writeDB(db);
  res.json(db.categories[idx]);
});

app.delete('/api/categories/:id', (req, res) => {
  const db = readDB();
  db.categories = db.categories.filter(c => c.id != req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// ARTICLES
app.get('/api/articles', (req, res) => {
  const db = readDB();
  let articles = db.articles;
  if (req.query.section) articles = articles.filter(a => a.section === req.query.section);
  if (req.query.categorie_id) articles = articles.filter(a => a.categorie_id == req.query.categorie_id);
  if (req.query.search) {
    const s = req.query.search.toLowerCase();
    articles = articles.filter(a => 
      a.id.toLowerCase().includes(s) || 
      a.designation.toLowerCase().includes(s) || 
      (a.designation_ar && a.designation_ar.includes(req.query.search))
    );
  }
  res.json(articles);
});

app.get('/api/articles/:id', (req, res) => {
  const db = readDB();
  const art = db.articles.find(a => a.id === req.params.id);
  if (!art) return res.status(404).json({ error: 'Article non trouvé' });
  res.json(art);
});

app.post('/api/articles', (req, res) => {
  const db = readDB();
  const { utilisateur, ...articleData } = req.body;
  if (!articleData.id) {
    db._counters.article_custom_id++;
    articleData.id = 'ART-' + String(db._counters.article_custom_id).padStart(3, '0');
  }
  if (db.articles.find(a => a.id === articleData.id)) {
    return res.status(400).json({ error: 'Un article avec cet identifiant existe déjà' });
  }
  db.articles.push(articleData);
  addHistorique(db, utilisateur || 'Système', 'Ajout article', articleData.id, `Ajout de "${articleData.designation}"`, '', JSON.stringify(articleData));
  writeDB(db);
  res.json(articleData);
});

app.put('/api/articles/:id', (req, res) => {
  const db = readDB();
  const idx = db.articles.findIndex(a => a.id === req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Article non trouvé' });
  const { utilisateur, ...updateData } = req.body;
  const ancien = JSON.stringify(db.articles[idx]);
  db.articles[idx] = { ...db.articles[idx], ...updateData };
  addHistorique(db, utilisateur || 'Système', 'Modification article', req.params.id, `Modification de "${db.articles[idx].designation}"`, ancien, JSON.stringify(db.articles[idx]));
  writeDB(db);
  res.json(db.articles[idx]);
});

app.delete('/api/articles/:id', (req, res) => {
  const db = readDB();
  const art = db.articles.find(a => a.id === req.params.id);
  if (!art) return res.status(404).json({ error: 'Article non trouvé' });
  const utilisateur = req.query.utilisateur || 'Système';
  db.articles = db.articles.filter(a => a.id !== req.params.id);
  addHistorique(db, utilisateur, 'Suppression article', req.params.id, `Suppression de "${art.designation}"`, JSON.stringify(art), '');
  writeDB(db);
  res.json({ success: true });
});

// MOUVEMENTS
app.get('/api/mouvements', (req, res) => {
  const db = readDB();
  let mouvs = db.mouvements;
  if (req.query.type) mouvs = mouvs.filter(m => m.type === req.query.type);
  if (req.query.article_id) mouvs = mouvs.filter(m => m.article_id === req.query.article_id);
  if (req.query.date_from) mouvs = mouvs.filter(m => m.date >= req.query.date_from);
  if (req.query.date_to) mouvs = mouvs.filter(m => m.date <= req.query.date_to + 'T23:59:59');
  if (req.query.limit) mouvs = mouvs.slice(0, parseInt(req.query.limit));
  res.json(mouvs);
});

app.post('/api/mouvements', (req, res) => {
  const db = readDB();
  const { article_id, quantite, type, demandeur, motif, fournisseur, valide_par, date, utilisateur } = req.body;
  const artIdx = db.articles.findIndex(a => a.id === article_id);
  if (artIdx === -1) return res.status(404).json({ error: 'Article non trouvé' });
  
  const art = db.articles[artIdx];
  const qty = parseFloat(quantite);
  
  if (type === 'sortie') {
    if (qty > art.quantite) {
      return res.status(400).json({ error: `Stock insuffisant. Disponible: ${art.quantite} ${art.unite}` });
    }
    db.articles[artIdx].quantite = Math.round((art.quantite - qty) * 1000) / 1000;
  } else {
    db.articles[artIdx].quantite = Math.round((art.quantite + qty) * 1000) / 1000;
  }
  
  db._counters.mouvement_id++;
  const mouvement = {
    id: db._counters.mouvement_id,
    type,
    article_id,
    article_designation: art.designation,
    article_designation_ar: art.designation_ar,
    article_unite: art.unite,
    quantite: qty,
    quantite_avant: art.quantite,
    quantite_apres: db.articles[artIdx].quantite,
    demandeur: demandeur || '',
    motif: motif || '',
    fournisseur: fournisseur || '',
    valide_par: valide_par || utilisateur || '',
    date: date || new Date().toISOString(),
    utilisateur: utilisateur || 'Système'
  };
  
  db.mouvements.unshift(mouvement);
  addHistorique(db, utilisateur || 'Système', type === 'sortie' ? 'Bon de sortie' : "Bon d'entrée", article_id, 
    `${type === 'sortie' ? 'Sortie' : 'Entrée'}: ${qty} ${art.unite} - ${art.designation}`,
    String(art.quantite), String(db.articles[artIdx].quantite));
  
  writeDB(db);
  res.json(mouvement);
});

// HISTORIQUE
app.get('/api/historique', (req, res) => {
  const db = readDB();
  console.log(`[DEBUG] GET /api/historique — nb entrées: ${db.historique.length}`);
  let hist = db.historique;
  if (req.query.utilisateur) hist = hist.filter(h => h.utilisateur === req.query.utilisateur);
  if (req.query.action) hist = hist.filter(h => h.action === req.query.action);
  if (req.query.date_from) hist = hist.filter(h => h.date >= req.query.date_from);
  if (req.query.date_to) hist = hist.filter(h => h.date <= req.query.date_to + 'T23:59:59');
  res.json(hist);
});

// DASHBOARD STATS
app.get('/api/stats', (req, res) => {
  const db = readDB();
  const today = new Date().toISOString().split('T')[0];
  const ruptures = db.articles.filter(a => a.quantite === 0);
  const faibles = db.articles.filter(a => a.quantite > 0 && a.quantite <= a.seuil);
  const mouvementsAujourdhui = db.mouvements.filter(m => m.date && m.date.startsWith(today));
  
  const parCategorie = db.categories.map(cat => ({
    categorie: cat.nom,
    categorie_ar: cat.nom_ar,
    section: cat.section,
    total: db.articles.filter(a => a.categorie_id === cat.id).reduce((s, a) => s + a.quantite, 0),
    articles: db.articles.filter(a => a.categorie_id === cat.id).length
  }));

  const reservationsEnAttente = (db.reservations || []).filter(r => r.statut === 'en_attente').length;

  res.json({
    total_articles: db.articles.length,
    ruptures: ruptures.length,
    stock_faible: faibles.length,
    mouvements_jour: mouvementsAujourdhui.length,
    reservations_attente: reservationsEnAttente,
    par_categorie: parCategorie,
    voirie_count: db.articles.filter(a => a.section === 'Voirie').length,
    ep_count: db.articles.filter(a => a.section === 'Éclairage Public').length
  });
});

// ALERTES
app.get('/api/alertes', (req, res) => {
  const db = readDB();
  const ruptures = db.articles.filter(a => a.quantite === 0);
  const faibles = db.articles.filter(a => a.quantite > 0 && a.quantite <= a.seuil);
  res.json({ ruptures, stock_faible: faibles });
});

// RESERVATIONS
app.get('/api/reservations', (req, res) => {
  const db = readDB();
  let res2 = db.reservations || [];
  if (req.query.statut) res2 = res2.filter(r => r.statut === req.query.statut);
  if (req.query.agent) res2 = res2.filter(r => r.agent === req.query.agent);
  res.json(res2);
});

app.post('/api/reservations', (req, res) => {
  const db = readDB();
  if (!db.reservations) db.reservations = [];
  const { article_id, quantite, motif, chantier, urgence, utilisateur, nom_agent } = req.body;

  const art = db.articles.find(a => a.id === article_id);
  if (!art) return res.status(404).json({ error: 'Article non trouvé' });

  const qty = parseFloat(quantite);
  if (isNaN(qty) || qty <= 0) return res.status(400).json({ error: 'Quantité invalide' });

  db._counters.reservation_id = (db._counters.reservation_id || 0) + 1;
  const reservation = {
    id: db._counters.reservation_id,
    numero: 'RES-' + String(db._counters.reservation_id).padStart(4, '0'),
    article_id,
    article_designation: art.designation,
    article_designation_ar: art.designation_ar || '',
    article_unite: art.unite,
    quantite: qty,
    motif: motif || '',
    chantier: chantier || '',
    urgence: urgence || 'normale',
    agent: utilisateur || '',        // ← username de l'agent (ex: "agent")
    nom_agent: nom_agent || utilisateur || '',
    statut: 'en_attente',
    date_demande: new Date().toISOString(),
    date_traitement: null,
    traite_par: '',
    commentaire_traitement: ''
  };

  db.reservations.unshift(reservation);
  addHistorique(db, utilisateur || 'Système', 'Réservation article', article_id,
    `Réservation N°${reservation.numero}: ${qty} ${art.unite} - ${art.designation}`,
    '', JSON.stringify({ quantite: qty, motif, chantier }));
  writeDB(db);
  res.json(reservation);
});

app.put('/api/reservations/:id', (req, res) => {
  const db = readDB();
  if (!db.reservations) db.reservations = [];
  const idx = db.reservations.findIndex(r => r.id == req.params.id);
  if (idx === -1) return res.status(404).json({ error: 'Réservation non trouvée' });

  const { statut, commentaire_traitement, utilisateur } = req.body;
  const resa = db.reservations[idx];

  // If approving → create automatic bon de sortie
  if (statut === 'approuvee') {
    const artIdx = db.articles.findIndex(a => a.id === resa.article_id);
    if (artIdx === -1) return res.status(404).json({ error: 'Article non trouvé' });
    const art = db.articles[artIdx];
    if (resa.quantite > art.quantite) {
      return res.status(400).json({ error: `Stock insuffisant. Disponible: ${art.quantite} ${art.unite}` });
    }
    db.articles[artIdx].quantite = Math.round((art.quantite - resa.quantite) * 1000) / 1000;

    db._counters.mouvement_id = (db._counters.mouvement_id || 0) + 1;
    const mouvement = {
      id: db._counters.mouvement_id,
      type: 'sortie',
      article_id: resa.article_id,
      article_designation: art.designation,
      article_designation_ar: art.designation_ar,
      article_unite: art.unite,
      quantite: resa.quantite,
      quantite_avant: art.quantite,
      quantite_apres: db.articles[artIdx].quantite,
      demandeur: resa.nom_agent,
      motif: `[Réservation ${resa.numero}] ${resa.motif}`,
      fournisseur: '',
      valide_par: utilisateur || '',
      date: new Date().toISOString(),
      utilisateur: utilisateur || 'Système',
      reservation_id: resa.id
    };
    db.mouvements.unshift(mouvement);
    addHistorique(db, utilisateur || 'Système', 'Approbation réservation', resa.article_id,
      `Approbation ${resa.numero}: ${resa.quantite} ${art.unite} pour ${resa.nom_agent}`,
      String(art.quantite), String(db.articles[artIdx].quantite));
  } else if (statut === 'refusee') {
    addHistorique(db, utilisateur || 'Système', 'Refus réservation', resa.article_id,
      `Refus ${resa.numero}: ${commentaire_traitement || ''}`, '', '');
  }

  db.reservations[idx] = {
    ...resa,
    statut,
    date_traitement: new Date().toISOString(),
    traite_par: utilisateur || '',
    commentaire_traitement: commentaire_traitement || ''
  };

  writeDB(db);
  res.json(db.reservations[idx]);
});

app.delete('/api/reservations/:id', (req, res) => {
  const db = readDB();
  if (!db.reservations) db.reservations = [];
  db.reservations = db.reservations.filter(r => r.id != req.params.id);
  writeDB(db);
  res.json({ success: true });
});

// USERS (admin only)
app.get('/api/users', (req, res) => {
  const db = readDB();
  res.json(db.users.map(u => ({ id: u.id, username: u.username, role: u.role, nom: u.nom })));
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, '0.0.0.0', () => {
  console.log(`\n✅ Serveur démarré — http://localhost:${PORT}`);
  console.log(`📡 Réseau local: http://[votre-IP]:${PORT}`);
  console.log(`\n🔐 Comptes:`);
  console.log(`   admin / admin2025`);
  console.log(`   responsable / resp2025`);
  console.log(`   agent / agent2025\n`);
});
